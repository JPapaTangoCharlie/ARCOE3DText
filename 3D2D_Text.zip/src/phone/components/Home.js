// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


//Setup External Library 
var head = document.getElementsByTagName('head')[0];
var script = document.createElement('script');
script.type = 'text/javascript';
script.src = './app/resources/Uploaded/arcoe3DText.js';
head.appendChild(script);
$timeout(function(){
  arcoe3DText($scope, $element, $attrs, $timeout, tml3dRenderer);
},1000);

var msg = "Jack and Jill went up the hill," + "\n" + "To fetch a pail of water;" + "\n" + "Jack fell down, and broke his crown." + "\n" + "And Jill came tumbling after."

pageProps = {
    "debug":false,
    "widgetsrc":"imgsrc",
    "textRightMargin": 23,
    "imageWidget": "image-2",
    "textAlign": "left",
    "FontColor": "rgba(255, 255, 255, 1.0);",
    "imgAlignH":"rightright",
    "imgAlignV":"bottombottom",
    "imageSrc": "app/resources/Uploaded/FAD_LOGO.png",
    "imageScale": 0.3,
    "message": "",
    "paragraphSplit": "\n",
    "betweenParagraphs": 0.35,
    "widthMeters": 0.089,
    "heightMeters": 0.049,
    "backingcolor": "rgba(120, 255, 100, 0.5)",
    "canvasFont": "Arial",
    "lineheightratio": 0.9,
    "fontSize": 25,
    "textStartX": 10,
    "textStartY": 25
  };

$scope.showText2D = function(){
  var pgdata = pageProps;	//Do this to keep default values if needed again;
  pgdata.message = msg;
  $scope.doText(pgdata);
}

$scope.showText3D = function(){
  pgdata = pageProps;	//Do this to keep default values if needed again;
  pgdata.widgetsrc = "src";
  pgdata.imageWidget = "3DImage-1";
  pgdata.message = msg;
  $scope.doText(pgdata);
}
